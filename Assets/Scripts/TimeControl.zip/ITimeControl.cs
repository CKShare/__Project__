﻿using UnityEngine;

public interface ITimeControl
{
    void AdjustTimeScale(float timeScale);
}